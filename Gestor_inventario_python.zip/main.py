from GUI.login import loginWindows

def main():
    # Iniciar la ventana de login
    loginWindows()

if __name__ == "__main__":
    main()