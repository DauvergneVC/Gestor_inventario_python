# DataBase config
DB_HOST = 'mysql-gestorinventariopython.alwaysdata.net'
DB_USER = '362665_inventory'
DB_PASSWORD = 'vjrb1234'
DB_NAME = 'gestorinventariopython_database'